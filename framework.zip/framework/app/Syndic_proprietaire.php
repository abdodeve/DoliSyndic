<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Syndic_proprietaire extends Model
{
    protected $table          = 'syndic_proprietaire';
    protected $primaryKey     = 'rowid';
}
