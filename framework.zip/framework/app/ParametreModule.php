<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ParametreModule extends Model
{
    protected $table          = 'syndic_parametre';
    protected $primaryKey     = 'rowid';
}
