<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class llx_user extends Model
{
    protected $table          = 'user';
    protected $primaryKey     = 'rowid';
}
