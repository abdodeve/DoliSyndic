Hello Al3chrrrrrran 
<h1>
<?php print_r($data); ?>
</h1>